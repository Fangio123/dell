import re


def format_excl_inst(excludeinstance):
    modfd_excl_inst = None
    if (excludeinstance):
        try:
            if(not comma_sep_ele_pairs(excludeinstance)):
                argPassed = re.split(r'\sor\s', excludeinstance, flags=re.IGNORECASE)
                modfd_excl_inst = get_cond_nameval_pair(argPassed)
            else:
                modfd_excl_inst = excludeinstance
        except IndexError as error:
            modfd_excl_inst = excludeinstance

        if modfd_excl_inst == "":
            modfd_excl_inst = excludeinstance
    return modfd_excl_inst

def get_cond_nameval_pair(conditions):
    modfd_excl_inst = ""
    for cond in conditions:
        cond = cond.strip()
        name_val_pair = []
        if re.search(r"\s?==\s?", cond, flags=re.IGNORECASE):
            name_val_pair = re.split(r'\s?==\s?', cond, flags=re.IGNORECASE)
        elif re.search(r"\sin\s*\(", cond, flags=re.IGNORECASE):
            name_val_pair = get_inst_name_value(cond)
        values = name_val_pair[1].strip().split(',')
        for val in values:
            instElem = (name_val_pair[0].strip() + '==' + val.strip("'"))
            modfd_excl_inst = (modfd_excl_inst + "," + instElem).strip(",")
    return modfd_excl_inst

def comma_sep_ele_pairs(excludeinstance):
    rx_comma_pairs = re.compile(r"(?:Status==([\w\s().-]+),?)")
    if(rx_comma_pairs.match(excludeinstance)):
        return True
    return False


def get_inst_name_value(element_str):
    name_val_list = []
    device_type = None
    split_in = re.split(r'\sIN\s*', element_str, flags=re.IGNORECASE)
    name = split_in[0]
    if(name):
        name_val_list.insert(0,name)
    match_list1 = re.findall(r"in\s*\((.*[^\)]*?)\)",
                            element_str,re.IGNORECASE)
    if match_list1 and len(match_list1) > 0:
        val = match_list1[0]
        name_val_list.insert(1,val)
    return name_val_list


def get_attr_eq_cond(element_str,attr_dict):
    split_eq = re.split(r'\s?==\s?', element_str)
    attr_dict.setdefault(split_eq[0], []).append(split_eq[1])
    return attr_dict

def get_attr_in_cond(element_str,attr_dict):
    split_in = re.split(r'\sIN\s*', element_str, flags=re.IGNORECASE)
    attr_name = split_in[0]
    vals_str = re.findall(r"IN\s*\((.*[^\)]*?)\)",
                             element_str, re.IGNORECASE)
    if(vals_str):
        attr_vals = re.split(",",vals_str[0])
        for val in attr_vals:
            val = val.strip("'")
            attr_dict.setdefault(attr_name, []).append(val)
    return attr_dict

def parse_excl_cond(excl_str):
    attr_dict = {}
    or_splited = re.split(r'\sor\s', excl_str, flags=re.IGNORECASE)
    for cond in or_splited:
        if re.search(r"\s?==\s?", cond, flags=re.IGNORECASE):
            attr_dict = get_attr_eq_cond(cond,attr_dict)
        elif re.search(r"\sin\s*\(", excl_str, flags=re.IGNORECASE):
            attr_dict = get_attr_in_cond(cond,attr_dict)
    return attr_dict