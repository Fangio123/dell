
#############################################################################################
#Title: regex_utility
#Version:3.1
#Creation Date: 10-Dec-2019
#Author : Priyanka Patil
#Description: regex_utility.py is utility which is used to search and modify file content.
# Copyright (c) 2018 - 2019 Dell Inc. or its subsidiaries. All rights reserved. Dell, EMC,
# and other trademarks are trademarks of Dell Inc. or its subsidiaries.
# Other trademarks may be trademarks of their respective owners.
############################################################################################
import re
import nagios_constants
import nagios_properties
from dellemc_device_data_extractor import write_log
import datetime



def get_services_regex(services,device_name):
    services_regex = None
    servive_pattern = ""
    unique_services = []
    for component in services:
        if (not component in unique_services):
            component_name = get_comp_match_name(component,device_name)
            if not servive_pattern:
                servive_pattern = component_name
            else:
                servive_pattern = servive_pattern + "|" + component_name
            unique_services.append(component_name)
    if (servive_pattern):
        servive_pattern = "(" + servive_pattern + ")"
        services_regex = re.compile(r"(?s).*?" + servive_pattern)
    return services_regex


def component_services_regex(addservices, removeservices,file_content):
    rx_enable = None
    rx_disable = None
    for services in addservices:
        if(services in removeservices):
            removeservices.remove(services)
    device_type = get_device_type(file_content)
    if addservices:
        rx_enable = get_services_regex(list(set(addservices)),device_type)
    if removeservices:
        rx_disable = get_services_regex(list(set(removeservices)),device_type)
    return (rx_enable, rx_disable)

def get_serv_name(str,file_content):
    service = None
    if nagios_constants.TRAP_SERVICE_DESCR in str:
        service = get_service_by_desc(r"(?s).*?",file_content)
    else:
        service = re.search("--componentname=(.*?)\!",str).group(1)
    return service;

def comment_uncomment_service(file_content, addservices, removeservices):
    write_log("enable_disable_service start", "info")
    new_content = file_content
    modified_serv = None
    added_serv = []
    removed_serv = []
    (rx_include, rx_exclude) = component_services_regex(addservices, removeservices,file_content)
    rx_group = re.compile(r"([# \t]*define\s+service\s*\{[^\}]*\})")
    rx_comment = re.compile(r"^", re.MULTILINE)
    rx_uncomment = re.compile(r"^\s*[#\s]*", re.MULTILINE)
    for match in rx_group.finditer(file_content):
        if rx_include and rx_include.match(match.group(1)):
            uncommented = rx_uncomment.sub("", match.group(1))
            new_content = new_content.replace(match.group(1), uncommented)
            added_serv.append(get_serv_name(rx_include.match(match.group(1)).group(1),file_content))


        if rx_exclude and rx_exclude.match(match.group(1)):
            uncommented = rx_uncomment.sub("", match.group(1))
            commented = rx_comment.sub("# ", uncommented)
            new_content = new_content.replace(match.group(1), commented)
            removed_serv.append(get_serv_name(rx_exclude.match(match.group(1)).group(1),file_content))

    if(len(added_serv)>0 or len(removed_serv)>0):
        modified_serv = {"ADDED":get_component_names(added_serv),"REMOVED":get_component_names(removed_serv)}

    write_log("enable_disable_service start", "info")
    return new_content, modified_serv


def uncomment_services(file_content):
    write_log("enable_disable_service start", "info")
    write_log(datetime.datetime.now().time(), "info")
    new_content = file_content
    modified = False
    rx_group = re.compile(r"([# \t]*define\s+service\s*\{[^\}]*\})")
    rx_uncomment = re.compile(r"^\s*[#\s]*", re.MULTILINE)
    for match in rx_group.finditer(file_content):
        uncommented = rx_uncomment.sub("", match.group(1))
        new_content = new_content.replace(match.group(1), uncommented)
        modified = True
    return new_content, modified


def exclude_instance(objectfile_content,exclude_string,component):
    modified = False
    new_content = objectfile_content
    rx_component = re.compile(r"(?s).*?" + "--componentname=" + component + "!")
    rx_exlinstance = re.compile(r"--excludeinstance=\"(.*?)\"!")
    rx_group = re.compile(r"([# \t]*define\s+service\s*\{[^\}]*\})")
    for match in rx_group.finditer(objectfile_content):
        if rx_component.match(match.group(1)):
            exclude_inst_pattern = re.findall(rx_exlinstance, match.group(1))
            if (len(exclude_inst_pattern) > 0 ):
                new_content = new_content.replace(match.group(1), rx_exlinstance.sub("--excludeinstance=\""
                                                                                     + exclude_string + "\"!",
                                                                                     match.group(1)))
                modified = True
    return new_content,modified

def chk_excl_inst_for_serv(component,objectfile_content):
    rx_component = re.compile(r"(?s).*?" + component)
    rx_exlinstance = re.compile(r"--excludeinstance=\"(.*?)\"!")
    rx_group = re.compile(r"([# \t]*define\s+service\s*\{[^\}]*\})")
    for match in rx_group.finditer(objectfile_content):
        if rx_component.match(match.group(1)):
            exclude_inst_pattern = re.findall(rx_exlinstance, match.group(1))
            if (len(exclude_inst_pattern) <= 0):
                return False
    return True

def check_hostgroup(content, hostgrp_name):
    rx_hostgrp = re.search(r"hostgroups\s*" + hostgrp_name + "[\r\n]", content, re.DOTALL)
    if hostgrp_name == nagios_constants.HOSTGROUP_VXRAIL and not rx_hostgrp:
        rx_hostgrp = check_vxrail_with_dyn_hostgrp(content, hostgrp_name)
    return rx_hostgrp

def search_component_services(file_content):
    component_list = re.findall(r"--componentname=(.*?)\!",
                                file_content)

    disabled_component_list = re.findall(r"#.*--componentname=(.*?)\!",
                                         file_content)
    other_service = get_service_by_desc(r"(?s).*?",file_content)
    dis_other_services = get_service_by_desc(r"#.*?",file_content)
    if(other_service):
        component_list.append(other_service)
    if (dis_other_services):
        disabled_component_list.append(dis_other_services)
    return get_component_names(component_list),get_component_names(disabled_component_list)

def get_service_by_desc(regex,file_content):
    service = None
    if (re.findall(regex + nagios_constants.TRAP_SERVICE_DESCR,
                   file_content)):
        if(re.findall(r"(?s).*?" + nagios_constants.TRAP_SERVICE_GROUP_PS+"|"+nagios_constants.TRAP_SERVICE_GROUP_SC,
                   file_content)):
            service = nagios_constants.TRAPG_SERVICE
        else:
            service = nagios_constants.TRAP_SERVICE
    return service

def get_component_names(comp_list):
    sorted_services = []
    if comp_list:
        for index, comp in enumerate(comp_list):
            if("," in comp):
                cmplst = comp.split(",");
                comp_list[index] = cmplst[0]
        sorted_services = list(set(comp_list))
        sorted_services.sort()
    return sorted_services

def get_device_type(file_content):
     device_type = None
     match_list   = re.findall(r"--devicetype=(.*?)\!",
                                file_content)
     if match_list and len(match_list)>0:
         device_type = match_list[0]
     return device_type

def get_comp_match_name(component,device_type):
    service_name = component
    services = nagios_properties.dell_device_services.get(device_type)
    if(services):
        comp_service = services.get(component)
        if(comp_service):
            additional_comp = comp_service.get("requiredAdditionalComponent")
            if(additional_comp and len(additional_comp)>0):
                service_name = service_name +","+additional_comp
    if (component == nagios_constants.TRAP_SERVICE or component == nagios_constants.TRAPG_SERVICE):
        component_pattern = nagios_constants.TRAP_SERVICE_DESCR
    else:
        component_pattern = "--componentname=" + service_name.strip() + "!"
    return component_pattern

def check_vxrail_with_dyn_hostgrp(filecontent,hostgrp_name):
    hostgrp_name = get_vxrail_vmmurl_grpname(filecontent, hostgrp_name)
    rx_hostgrp = re.search(r"hostgroups\s*" + hostgrp_name + "[\r\n]", filecontent, re.DOTALL)
    return rx_hostgrp


def get_vxrail_vmmurl_grpname(filecontent,hostgrp):
    hostgrpstr = hostgrp
    vmmurl = get_action_url(filecontent)
    if(vmmurl):
            dyanamic_hostgrp = vmmurl.replace("https://", "Cluster_").replace(":", "_")
            hostgrpstr = hostgrp + "," + dyanamic_hostgrp
    return hostgrpstr

def get_action_url(filecontent):
    action_url = None
    findresult = re.findall(r"(?:action_url)(.*?)\n", filecontent, re.DOTALL)
    if (findresult and len(findresult) > 0):
        action_url = findresult[0].strip()
    return action_url