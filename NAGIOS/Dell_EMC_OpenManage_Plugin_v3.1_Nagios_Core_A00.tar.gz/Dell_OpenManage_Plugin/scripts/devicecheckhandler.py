# -*- coding: utf-8 -*-

# Dell EMC OpenManage Nagios Modules
# Version 3.1
# Copyright (C) 2019 Dell Inc. or its subsidiaries. All Rights Reserved.
# author : Sachin Apagundi
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:

#    * Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.

#    * Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from redfish import RedFishImpl, Components
import collections
import operator

class DeviceCheckHandler(object):
    """Base Class for Device Check Handler"""
    def __init__(self):
        """

        """
        self.component_name = None
        self.device_type = None
        self.module_params = {}
        self.comp_response = None
        self.exit_code_map = {'OK': 0, 'Warning': 1, 'Critical': 2, 'Unknown': 3}
        self.sorted_instance = None
        self.sorted_instance_count = None
        self.exit_code = None
        self.print_healthy = False
        self.status_info_netwk_text = "Total Instances: {ti}, Connected Instances: {hi}," \
                                       " Down Instances: {ci} <br>" \
                                       # ", Excluded Instances: {ei}"
        self.status_info_static_text = "Total Instances: {ti}, Healthy Instances: {hi}, Warning Instances: {wi}," \
                                       " Critical Instances: {ci}, Unknown Instances: {ui} <br>" \
                                       # ", Excluded Instances: {ei}<br>"
        self.static_detail_gen = "{critical_d}{warning_d}{healthy_d}{unknown_d}"
        self.static_detail_network = "{up_d}{down_d}{unknown_d}"
        self.static_detail_spl = "{healthy_d}{warning_d}{critical_d}{unknown_d}"

    def build_params(self, args):
        """
        NO arg needs to be implemented in overridden class
        :param args:
        :return:
        """
        pass

    def handle_check(self):
        """
        NO arg needs to be implemented in overridden class
        :return:
        """
        pass


class DeviceCheck(object):
    """Device Check Class to be called from Device Check script for handling requests"""
    def __init__(self):
        """ Init method for initializing the attributes """
        self.component_name = None
        self.device_type = None
        self.module_params = {}
        self.device_handler = None

    def _get_device_handler(self):
        """
        Uses reflection via getattr to find the Object to intialize based on device Type
        ex: device_type = iDRAC
        module name should be would be idrachandler
        class name should be would be IdracDeviceCheck

        ex: device_type = NGM
        module name should be would be ngmhandler
        class name should be would be NgmDeviceCheck
        :return: Class Object based on device type
        """
        device_type = self.device_type.lower()
        module = __import__(device_type + "handler")
        class_ = getattr(module, device_type.capitalize() + "DeviceCheck")
        return class_()

    def build_params(self, args):
        """
        builds the param and option arguments used in nagios
        :param args: takes arg parse lib parse object as an argument
        :return:
        """
        self.module_params.update({"hostname": args.host})
        self.module_params.update({"username": args.httpUser})
        self.module_params.update({"password": args.httpPassword})
        self.module_params.update({"devicetype": args.devicetype})
        self.module_params.update({"componentname": args.componentname})
        self.module_params.update({"excludeinstance": args.excludeinstance})
        self.module_params.update({"setservicestatus": args.setservicestatus})
        # add other params
        self.device_type = args.devicetype
        self.device_handler = self._get_device_handler()
        return self

    def process(self):
        """
        process the request based on handler defined
        ex: for device_type = Idrac
        IdracDeviceCheck.build_params().handle_check()
        :return:
        """
        return self.device_handler.build_params(self.module_params).handle_check()