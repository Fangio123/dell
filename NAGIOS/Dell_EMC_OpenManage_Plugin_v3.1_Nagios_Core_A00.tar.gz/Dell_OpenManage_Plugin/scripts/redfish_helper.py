from __future__ import division
import re

import nagios_constants
from dellemc_device_data_extractor import write_log

class RedfishHelper(object):
    def get_oem_resp(self,comp_name, json):
        comp_oem = None
        try:
            comp_oem = json["Oem"]["Dell"]["Dell" + comp_name]
        except KeyError as keyerr:
            write_log("KeyError occurred: {}".format(keyerr), "error")
        return comp_oem


    def _get_oem_resp(self,comp_name, json):
        comp_oem = None
        try:
            oem_comp = "Dell" + comp_name
            comp_oem = json["Oem"]["Dell"][oem_comp]
        except KeyError as keyerr:
            write_log("KeyError occurred: {}".format(keyerr), "error")
        return comp_oem

    def get_json_values(self,json,keys):
         value = None
         split_attr = keys.split('.')
         temp_data = json
         for i in range(len(split_attr)):
            if(isinstance(temp_data,dict)):
                temp_data = temp_data.  get(split_attr[i])
         value = temp_data
         return value

    def get_nic_fw_ver(self,adapter,nic_inst):
        firm_vers = None
        controller_list = adapter.get("Controllers")
        for controller in controller_list:
            nw_dev_functns = controller["Links"]["NetworkDeviceFunctions"]
            for nw_dev_func in nw_dev_functns:
                func_link = nw_dev_func.get("@odata.id")
                if re.search(nic_inst.get("Id"),func_link):
                    firm_vers = controller["FirmwarePackageVersion"]
                    return firm_vers
        return firm_vers

    def add_nic_port_info(self, nic_inst, nic_ports_resp):
        for nic_port in nic_ports_resp:
            if re.search(nic_port.get("Id"),nic_inst.get("Id")):
                nic_inst["LinkStatus"] = nic_port["LinkStatus"]
                if nic_port.get("CurrentLinkSpeedMbps") is None:
                    nic_inst["CurrentLinkSpeedMbps"] = nagios_constants.NOT_AVAILABLE
                else:
                    nic_inst["CurrentLinkSpeedMbps"] = str(nic_port.get("CurrentLinkSpeedMbps")) + " " \
                                                       + nagios_constants.MBPS

    def convert_mb_to_gb(self,size_mb):
        GB = 1024
        sizeGB = round(size_mb / GB,2)

        return str(sizeGB) + ' GB'

    def convert_bytes_to_gb(self, size_mb):
        GB = 1024*1024*1024
        sizeGB = round(size_mb / GB, 2)
        return str(sizeGB) + ' GB'