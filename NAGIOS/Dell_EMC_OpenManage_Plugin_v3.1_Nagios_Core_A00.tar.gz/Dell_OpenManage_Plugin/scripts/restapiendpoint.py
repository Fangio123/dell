# -*- coding: utf-8 -*-

# Dell EMC OpenManage Nagios Modules
# Version 3.1
# Copyright (C) 2019 Dell Inc. or its subsidiaries. All Rights Reserved.
# author : Sachin Apagundi
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:

#    * Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.

#    * Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

import json
import requests
import requests.packages.urllib3
from urllib3.exceptions import InsecureRequestWarning
from urllib3.exceptions import SNIMissingWarning
from urllib3.exceptions import InsecurePlatformWarning
import re


IPV6 = "IPv6"
IPV4 = "IPv4"


class ProcessResponse(object):
    """Handles HTTPResponse"""

    def __init__(self, resp):
        self.body = None
        self.resp = resp
        if self.resp:
            self.body = self.resp.content

    @property
    def json_data(self):
        try:
            if self.body:
                return json.loads(self.body)
        except ValueError:
            raise ValueError("Unable to parse json")

    @property
    def status_code(self):
        return self.resp.status_code

    @property
    def success(self):
        status = self.status_code
        return status >= 200 & status <= 299

    @property
    def headers(self):
        return self.resp.headers

    @property
    def reason(self):
        return self.resp.reason


class ProcessRequest(object):
    """Handles HTTP requests"""

    def __init__(self, module_params=None):
        self.module_params = module_params
        self.hostname = self.module_params["hostname"]
        self.port = self.module_params.get("port", '443')
        self.connection_timeout = self.module_params.get("connection_timeout", 20)
        self.read_timeout = self.module_params.get("read_timeout", 30)
        self.max_retries = self.module_params.get("max_retries", '1')
        self.validate_certs = self.module_params.get("validate_certs", False)
        self.use_proxy = self.module_params.get("use_proxy", True)
        self.session_id = None
        self.protocol = 'https'
        self.session = requests.session()
        self.session.mount("https://", requests.adapters.HTTPAdapter(
                pool_connections=1,
                max_retries=self.max_retries))
        self._update_headers({'Content-Type': 'application/json', 'Accept': 'application/json'})
        self.base_url = None
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
        requests.packages.urllib3.disable_warnings(InsecurePlatformWarning)
        requests.packages.urllib3.disable_warnings(SNIMissingWarning)
        requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    def _update_headers(self, headers):
        """updates header of a request"""
        self.session.headers.update(headers)

    def _get_base_url(self):
        """builds base url"""
        ip_ver = self._get_ip_ver(self.hostname)
        if ip_ver == IPV4:
            return '{0}://{1}:{2}'.format(self.protocol, self.hostname, self.port)
        elif ip_ver == IPV6:
            return '{0}://[{1}]:{2}'.format(self.protocol, self.hostname, self.port)
    def _build_url(self, path, query_param=None):
        """
        builds complete url"
        :param path: path to request without query parameter 
        :param query_param: (optional) Dictionary of query parameter to send with request
        :return: url : complete url for the request
        """""
        if self.base_url is None:
            self.base_url = self._get_base_url()
        url = self.base_url
        if path:
            url += path
        if query_param:
            url += "?{0}".format(query_param)
        return url

    def _invoke_request(self, path, method='GET', query_param=None, headers=None, payload=None):
        """
        Sends a request
        Returns :class:`OpenURLResponse` object.
        :arg path: path to request without query parameter
        :arg method: (optional) by default we do get unless specified
        :arg query_param: (optional) Dictionary of query parameter to send with request
        :arg headers: (optional) Dictionary of HTTP Headers to send with the
            request
        :arg payload: (Optional) boolean value for dumping payload data.
        :returns: OpenURLResponse
        """
        try:
            if headers:
                self._update_headers(headers)

            url = self._build_url(path, query_param=query_param)
            if method == 'GET':
                resp = self.session.get(url, timeout=(self.connection_timeout, self.read_timeout), headers=headers)
            elif method == 'POST' and payload:
                request = requests.Request(method, url, data=json.dumps(payload))
                prepared_request = self.session.prepare_request(request)
                resp = self.session.send(prepared_request, timeout=(self.connection_timeout, self.read_timeout),
                                         verify=False)
            elif method == 'DELETE':
                resp = self.session.delete(url)
            else:
                print("Invalid request please check the method and payload")

            resp_data = ProcessResponse(resp)
        except requests.exceptions.ConnectionError as err:
            raise err
        except requests.exceptions.Timeout as err:
            raise err
        return resp_data

    def invoke_get(self, path, query_param=None, headers=None):
        """
        Sends a get request with a given URL
        :param path:
        :param query_param:
        :param headers:
        :return:
        """
        return self._invoke_request(path, 'GET', query_param, headers)

    def invoke_post(self, path, query_param=None, headers=None, payload=None):
        """
        Sends a post request with a given URL
        :param path:
        :param query_param:
        :param headers:
        :param payload:
        :return:
        """
        return self._invoke_request(path, 'POST', query_param, headers, payload)

    def invoke_delete(self, path, query_param=None, headers=None, payload=None):
        """
        Sends a delete request with a given URL
        :param path:
        :param query_param:
        :param headers:
        :param payload:
        :return:
        """
        return self._invoke_request(path, 'DELETE', query_param, headers, payload)

    def _get_ip_ver(self,hostname):
        ip_ver = ""
        IPV4SEG = r'(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])'
        IPV4ADDR = r'(?:(?:' + IPV4SEG + r'\.){3,3}' + IPV4SEG + r')'
        IPV6SEG = r'(?:(?:[0-9a-fA-F]){1,4})'
        IPV6GROUPS = (
            r'(?:' + IPV6SEG + r':){7,7}' + IPV6SEG,  # 1:2:3:4:5:6:7:8
            r'(?:' + IPV6SEG + r':){1,7}:',  # 1::                                 1:2:3:4:5:6:7::
            r'(?:' + IPV6SEG + r':){1,6}:' + IPV6SEG,  # 1::8               1:2:3:4:5:6::8   1:2:3:4:5:6::8
            r'(?:' + IPV6SEG + r':){1,5}(?::' + IPV6SEG + r'){1,2}',  # 1::7:8             1:2:3:4:5::7:8   1:2:3:4:5::8
            r'(?:' + IPV6SEG + r':){1,4}(?::' + IPV6SEG + r'){1,3}',  # 1::6:7:8           1:2:3:4::6:7:8   1:2:3:4::8
            r'(?:' + IPV6SEG + r':){1,3}(?::' + IPV6SEG + r'){1,4}',  # 1::5:6:7:8         1:2:3::5:6:7:8   1:2:3::8
            r'(?:' + IPV6SEG + r':){1,2}(?::' + IPV6SEG + r'){1,5}',  # 1::4:5:6:7:8       1:2::4:5:6:7:8   1:2::8
            IPV6SEG + r':(?:(?::' + IPV6SEG + r'){1,6})',  # 1::3:4:5:6:7:8     1::3:4:5:6:7:8   1::8
            r':(?:(?::' + IPV6SEG + r'){1,7}|:)',  # ::2:3:4:5:6:7:8    ::2:3:4:5:6:7:8  ::8       ::
            r'fe80:(?::' + IPV6SEG + r'){0,4}%[0-9a-zA-Z]{1,}',
            # fe80::7:8%eth0     fe80::7:8%1  (link-local IPv6 addresses with zone index)
            r'::(?:ffff(?::0{1,4}){0,1}:){0,1}[^\s:]' + IPV4ADDR,
            # ::255.255.255.255  ::ffff:255.255.255.255  ::ffff:0:255.255.255.255 (IPv4-mapped IPv6 addresses and IPv4-translated addresses)
            r'(?:' + IPV6SEG + r':){1,4}:[^\s:]' + IPV4ADDR,
        # 2001:db8:3:4::192.0.2.33  64:ff9b::192.0.2.33 (IPv4-Embedded IPv6 Address)
        )
        IPV6ADDR = '|'.join(['(?:{})'.format(g) for g in IPV6GROUPS[::-1]])  # Reverse rows for greedy match
        if re.match(IPV6ADDR,hostname):
            ip_ver = IPV6
        elif re.match(IPV4ADDR,hostname):
            ip_ver = IPV4

        return ip_ver
