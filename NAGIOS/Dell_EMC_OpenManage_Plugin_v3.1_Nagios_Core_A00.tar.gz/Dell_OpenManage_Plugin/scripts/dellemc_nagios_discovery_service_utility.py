
#############################################################################################
#Title:dellemc_nagios_discovery_service_utility.py
#Version:3.0 
#Creation Date: 01-Apr-2018
#Description: dellemc_nagios_discovery_service_utility.py, used for dell emc device discovery.
#Copyright (c) 2018 Dell Inc. or its subsidiaries. All rights reserved. Dell, EMC,
#             and other trademarks are trademarks of Dell Inc. or its subsidiaries.
#			  Other trademarks may be trademarks of their respective owners.
############################################################################################
import nagios_messages

#Local libraries
from dellemc_helper_utility import parse_argument, parse_properties
from command_builder import CommandFactory

def call(args):
    try:
        cmd_executor = None
        output_msg = None

        parser = parse_argument()
        results,cmd_args = parse_properties(parser, args)
        cmd_factory = CommandFactory(results,cmd_args)        
        inval_msg,invalid_flag = cmd_factory.check_valid_inputs()
        if(invalid_flag):
            output_msg = inval_msg
        else:
            cmd_executor = cmd_factory.load_executor()
            if (cmd_executor):
                cmd_factory.print_progress_msg()
                output_msg = cmd_executor.execute()
            else:
                output_msg = nagios_messages.invalid_cmd
        cmd_factory.print_summary(cmd_executor,output_msg)
    except ImportError as details:
        print(details)
    except Exception as err:
        print(err)


if __name__ == "__main__":
    call(None)


