
#############################################################################################
#Title: update_services_utility
#Version:3.1
#Creation Date: 10-Dec-2019
#Author : Priyanka Patil
#Description: update_services_utility.py is used to comment and uncomment services at host and hostgroup level.
# Copyright (c) 2018 - 2019 Dell Inc. or its subsidiaries. All rights reserved. Dell, EMC,
# and other trademarks are trademarks of Dell Inc. or its subsidiaries.
# Other trademarks may be trademarks of their respective owners.
############################################################################################

import nagios_messages

from dellemc_filehandler_utility import *
import datetime
from dellemc_device_data_extractor import write_log
from list_services_utility import get_hostgroup_services
from regex_utility import search_component_services, chk_excl_inst_for_serv
import nagios_properties

from regex_utility import comment_uncomment_service,uncomment_services,check_hostgroup,exclude_instance



def enable_all_services_host(host, cfg_location):
    output_message = ""
    # TODO check for unique services
    filename = create_file_path(host, cfg_location)
    objectfile_content = read_file(filename)
    (objectfile_content, is_modified) = uncomment_services(objectfile_content)
    if is_modified:
        write_file(filename,objectfile_content)
        output_message = nagios_messages.enable_all_service_host_success.format(host)
    else:
        output_message =  nagios_messages.enable_all_service_host_added.format(filename.strip(".cfg"))
    return output_message

def enable_all_services_hostgroup(hostgroup, cfg_location):
    output_message = ""
    write_log("update_hostgroup_services start time:{}".format(datetime.datetime.now().time()), "info")
    hostfiles = list_all_files(cfg_location)
    for filename in hostfiles:
        if(filename.endswith(".cfg")):
            filepath = get_file_path(cfg_location,filename)
            objectfile_content = read_file(filepath)
            if(not objectfile_content):
                message = nagios_messages.enable_all_service_host_failed.format(filename.strip(".cfg"))
                output_message = append_output_message(output_message, message)
            else:
                hostgroup_matches = check_hostgroup(objectfile_content, hostgroup)
                if (hostgroup_matches):
                    (objectfile_content, is_modified) = uncomment_services(objectfile_content)
                    if is_modified:
                        write_file(filepath,objectfile_content)
                        message = nagios_messages.enable_all_service_host_success.format(filename.strip(".cfg"))
                        output_message = append_output_message(output_message,message)
                    else:
                        message = nagios_messages.enable_all_service_host_added.format(filename.strip(".cfg"))
                        output_message = append_output_message(output_message, message)
        else:
            write_log("file is not cfg"+filename,"info")
    write_log("update_hostgroup_services end time:{}".format(datetime.datetime.now().time()), "info")
    return output_message

def update_services(addservices,removeservices,objectfile_content,filename,msgnane):
    output_message = ""
    add_message = ""
    remove_message = ""
    (services_configured, modified_serv) = comment_uncomment_service(objectfile_content, addservices,
                                                                removeservices)
    if (modified_serv):
        write_file(filename,services_configured)
        if len(modified_serv.get("ADDED")) > 0 :
            add_message = nagios_messages.service_added.format(modified_serv.get("ADDED"))
        if len(modified_serv.get("REMOVED")) > 0:
            if add_message:
                remove_message += " and "
            remove_message += nagios_messages.service_removed.format(modified_serv.get("REMOVED"))
        output_message = nagios_messages.update_service_host_success.format(add_message,remove_message,
                             msgnane)
    else:
        output_message = nagios_messages.update_service_failed.format(
            msgnane)
    return output_message

def update_services_host(host, addservices, removeservices, cfg_location):
    output_message = ""
    # TODO check for unique services
    filename = create_file_path(host, cfg_location)
    objectfile_content = read_file(filename)
    if (not chk_available_services(addservices, objectfile_content) or not chk_available_services(
            removeservices, objectfile_content)):
        output_message = nagios_messages.services_not_found_cfg.format(host)
    else:
        output_message = update_services(addservices,removeservices,objectfile_content,filename,host)
    return output_message

def update_services_hostgroup(hostgroup, addservices, removeservices, cfg_location):
    output_message = ""
    if(not hostgroup in get_all_hostgroup()):
        output_message = nagios_messages.hostgroup_not_supported
    else:
        if (not chk_avl_services_hostgroup(addservices, hostgroup) or not chk_avl_services_hostgroup(
                removeservices, hostgroup)):
            output_message = nagios_messages.services_not_appl_to_hostgroup.format(hostgroup)
        else:
            hostfiles = list_all_files(cfg_location)
            host_list = []
            for filename in hostfiles:
                if (filename.endswith(".cfg")):
                    filepath = get_file_path(cfg_location, filename)
                    objectfile_content = read_file(filepath)
                    hostgroup_matches = check_hostgroup(objectfile_content, hostgroup)
                    if (hostgroup_matches):
                        host_list.append(filename.strip(".cfg"))
                        message = update_services(addservices, removeservices, objectfile_content, filepath,
                                                   filename.strip(".cfg"))
                        output_message = append_output_message(output_message,message)
                else:
                    write_log("file is not cfg" + filename, "info")
            if(not len(host_list)>0):
                output_message = nagios_messages.update_service_hostgroup_not_found
    return output_message


def exclude_component_instance(host, exclude_string, component_service, cfg_location):
    modified = False
    output_message = ""
    filename = create_file_path(host, cfg_location)
    objectfile_content = read_file(filename)
    if (not objectfile_content):
        output_message = nagios_messages.excl_inst_host_file_not_exist
    else:
        valid,validate_msg = validate_excl_cond(component_service, objectfile_content)
        if (not valid):
            output_message = validate_msg
        else:
            (new_content, modified) = exclude_instance(objectfile_content, exclude_string, component_service)
            if (modified):
                write_file(filename, new_content)
                output_message = nagios_messages.excl_instance_host_success.format(component_service, host)
            else:
                output_message = nagios_messages.excl_instance_host_failed.format(component_service, host)
    return output_message

def validate_excl_cond(component_service,objectfile_content):
    valid = False
    validate_msg = ""
    if (not chk_avl_service(component_service, objectfile_content)):
        validate_msg = nagios_messages.service_not_found_cfg
        valid = False
    elif (not chk_excl_inst_for_serv(component_service, objectfile_content)):
        validate_msg = nagios_messages.excl_condn_not_found_for_service
        valid = False
    else:
        valid = True
    return valid,validate_msg

def chk_available_services(services,file_content):
    if services:
        services_list,disabled_serv = search_component_services(file_content)
        for service in services:
            if(not service in services_list):
                return False
    return True

def chk_avl_services_hostgroup(services,hostgroup):
    if services:
        hostgrp_services = get_hostgroup_services(hostgroup)
        for service in services:
            if(not service in hostgrp_services):
                return False
    return True


def get_all_hostgroup():
    hostgrp_list = []
    for key, value in nagios_properties.device_data.items():
        hostgrp_list.append(value["hostgroup"])
        if(value.get("hostgroupXC")):
            hostgrp_list.append(value.get("hostgroupXC"))
        if (value.get("hostgroupVxRail")):
            hostgrp_list.append(value.get("hostgroupVxRail"))
        if (value.get("hostgroupVxFlex")):
            hostgrp_list.append(value.get("hostgroupVxFlex"))
    return list(set(hostgrp_list))

def append_output_message(output_message,message):
    if (output_message):
        output_message += "\n" + message
    else:
        output_message = message
    return output_message

def chk_avl_service(service,filecontent):
    services_list, disabled_serv = search_component_services(filecontent)
    enabled_services = [component for component in services_list if component not in disabled_serv]
    if(not service in enabled_services):
        return False
    return True

