# -*- coding: utf-8 -*-

# Dell EMC OpenManage Nagios Modules
# Version 3.1
# Copyright (C) 2019 Dell Inc. or its subsidiaries. All Rights Reserved.
# author : Sachin Apagundi
# Redistribution and use in source and binary forms, with or without modification,
# are permitted provided that the following conditions are met:

#    * Redistributions of source code must retain the above copyright notice,
#      this list of conditions and the following disclaimer.

#    * Redistributions in binary form must reproduce the above copyright notice,
#      this list of conditions and the following disclaimer in the documentation
#      and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
# IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
import nagios_constants
from device_check_exclude_instance import parse_excl_cond
from redfish import RedFishImpl, Components
from devicecheckhandler import DeviceCheckHandler
from label_attr_mapping import device_comp_attr_map
import collections


class IdracDeviceCheck(DeviceCheckHandler):
    """
        Device Check handler for Idrac devices must extend DeviceCheckHandler
    """
    def __init__(self):
        super(IdracDeviceCheck, self).__init__()
        self.status_val = {0:["OK","Up"], 1:["Warning"], 2:["Critical","Down","Error"], 3:["Unknown"]}
        self.NETWORK_CHANNEL_COMP = ["NIC", "FC"]
        self.comp_rollup = None
        self.comp_response = None
        self.sorted_instance = None
        self.sorted_instance_count = None
        self.total_i = 0
        self.warning_i = 0
        self.critical_i = 0
        self.unknown_i = 0
        self.exclude_i = 0

    def build_params(self, module_params):
        """
         build the params from the args
        :param module_params:
        :return:
        """
        self.module_params = module_params
        # add other params
        self.device_type = self.module_params['devicetype']
        self.component_name = self.module_params['componentname']
        if (self.component_name == "System,iDRAC"):
            self.component_name = "System"
        self.print_healthy = self.module_params.get('printhealthy', True)
        self.excl_condition = self.module_params['excludeinstance']
        self.setservicestatus = self.module_params['setservicestatus']
        self.comp_param_map = device_comp_attr_map.get(self.device_type).get(self.component_name)
        self.excl_inst_list = []
        return self

    def _get_comp_name(self):
        """returns the component Enum from the component name"""
        return Components[self.component_name]

    def _get_device_comp_response(self):
        """
        gets the response from the device for the component
        :return:
        """
        with RedFishImpl(module_params=self.module_params) as rf_impl:
            resp = rf_impl.get_components([self._get_comp_name()])
        return resp.get(self._get_comp_name().name)

    def handle_check(self):
        """
        handle method to handle the request
        :return:
        """
        resp_json = self._get_device_comp_response()
        if isinstance(resp_json,dict):
            self.comp_rollup = resp_json.get(nagios_constants.ROLLUP_HEALTH)
            self.comp_response = resp_json.get(nagios_constants.COMP_RESP)
        else:
            self.comp_response = resp_json
        status_info = self._get_status_information()
        exit_code = self._get_exit_code()
        return exit_code, status_info[:-4]

    def _get_status_information(self):

        if(self.component_name in ["System"]):
            status_info = self._get_inventory_info()
        elif(self.component_name in ["Subsystem"]):
            status_info = self._get_overall_health()
        else:
            self._sort_instance()
            if (self.excl_condition):
                self._exclude_instance(self.excl_condition)
            status_info = self._comp_status_info()
        return status_info

    def _get_exit_code(self):
        exit_code = 3
        if self.setservicestatus is None:
            if self.comp_rollup:
                exit_code = self._get_status_code(self.comp_rollup)
        else:
            exit_code = self.setservicestatus
        return exit_code

    def _sort_instance(self):
        """
        divides the response and creates a map based on the status from the response
        Also creates a map that hold the count of instances
        :return:
        """
        instances = collections.defaultdict(list)
        instances_c = collections.defaultdict(int)
        for inst in self.comp_response:
            status = self._get_attr_val(inst,self._get_status_field())
            status_code = self._get_status_code(status)
            instances[status_code].append(inst)
            instances_c[status_code] += 1
        self.sorted_instance = instances
        self.sorted_instance_count = instances_c

    def _calculate_health_status(self):
        """
        calculates the health of the components
        :return:
        """
        val = 3
        status_dict = self.sorted_instance
        if status_dict and len(status_dict.keys()) > 0:
            val = self._get_overall_status_code(status_dict)
        elif self.total_i > 0:
            if self.total_i == self.healthy_i:
                val = 0
        return val

    def _get_overall_status_code(self, status_dict):
        val = 3
        if 3 in status_dict.keys():
            status_dict.pop(3)
        if len(status_dict.keys()) > 0:
            if self.component_name not in self.NETWORK_CHANNEL_COMP:
                val = max(status_dict.keys())
            else:
                val = min(status_dict.keys())

        return val



    def _exclude_instance(self,excl_str):
        """
        excludes the instances depending on the exclude condition given in excl_str
        :return:
        """
        excl_dict = parse_excl_cond(excl_str)
        for key, value in dict(self.sorted_instance).items():
            inst_list = value
            for inst in list(inst_list):
                if (self._chk_excl(inst, excl_dict)):
                    self._remove_instance(inst,key)


    def _remove_instance(self,inst,key):
        if (len(self.sorted_instance[key]) > 1):
            if inst in self.sorted_instance[key]:
                self.excl_inst_list.append(inst)
                self.sorted_instance[key].remove(inst)

        else:
            self.excl_inst_list.append(inst)
            del self.sorted_instance[key]

    def _comp_status_info(self):
        st_text = ""
        self.total_i = sum(self.sorted_instance_count.values())
        if self.total_i > 0:
            self.healthy_i = 0 if self.sorted_instance_count.get(0) is None else self.sorted_instance_count.get(0)
            self.warning_i = 0 if self.sorted_instance_count.get(1) is None else self.sorted_instance_count.get(1)
            self.critical_i = 0 if self.sorted_instance_count.get(2) is None else self.sorted_instance_count.get(2)
            self.unknown_i = 0 if self.sorted_instance_count.get(3) is None else self.sorted_instance_count.get(3)
            self.exclude_i = 0
            if (self.component_name in self.NETWORK_CHANNEL_COMP):
                st_text = self.status_info_netwk_text.format(ti=self.total_i, hi=self.healthy_i, wi=self.warning_i, ci=self.critical_i,
                                                              ui=self.unknown_i, ei=self.exclude_i)
            else:
                st_text = self.status_info_static_text.format(ti=self.total_i, hi=self.healthy_i, wi=self.warning_i, ci=self.critical_i,
                                                          ui=self.unknown_i, ei=self.exclude_i)
            # if healthy_i and healthy_i == total_i:
            #     return st_text + self._get_detail_info(0, self.print_healthy)
            self.inst_no = 0

            if (self.component_name in self.NETWORK_CHANNEL_COMP):
                up_d = self._get_detail_info(0, self.print_healthy)
                down_d = self._get_detail_info(2)
                unknown_d = self._get_detail_info(3)
                st_text += self.static_detail_network.format(up_d=up_d, down_d=down_d, unknown_d=unknown_d)
            else:
                critical_d = self._get_detail_info(2)
                warning_d = self._get_detail_info(1)
                healthy_d = self._get_detail_info(0, self.print_healthy)
                unknown_d = self._get_detail_info(3)
                st_text += self.static_detail_gen.format(healthy_d=healthy_d, warning_d=warning_d, critical_d=critical_d,
                                                         unknown_d=unknown_d)
            if self.comp_rollup is None:
                st_text += "<br>[Rollup status not available]<br>"
        return st_text

    def _get_inventory_info(self):
        details =  self._get_values(self.comp_response[0])
        return details

    def _get_overall_health(self):
        details  =  self._get_values(self.comp_response[0])
        details = details.replace(",", "<br>")
        return details

    def _get_detail_info(self, status, print_value=True):
        details = ""
        status_data = self.sorted_instance.get(status, None)
        if status_data and len(status_data) > 0 and print_value:
            for val in status_data:
                self.inst_no = self.inst_no + 1
                details = details + "#{} ".format(self.inst_no) + self._get_values(val)
        return details

    def _get_values(self, inst):
        inst_detail = ''
        sep = ', '
        for attr, label in self.comp_param_map.items():
            split_attr = attr.split('.')
            temp_data = inst
            for i in range(len(split_attr)):
                if(isinstance(temp_data,dict)):
                   temp_data = self._get_val_map(temp_data, split_attr[i])
            if temp_data is None or temp_data == '':
                temp_data = 'Not Available'
            inst_detail = inst_detail + label + " = " + str(temp_data) + sep
        return inst_detail[:-2] + "<br>"

    def _get_val_map(self, data, attr):
        if(attr in ("Health")):
            if(not data.get(attr)):
                return 'Unknown'
        return data.get(attr, 'Not Available')

    def _get_status_code(self,status):
        code = 3
        for key, value in self.status_val.items():
            if status in value:
                code = key
        return code

    def _get_status_field(self):
        for key,val in self.comp_param_map.items():
            if val in ["Status","ConnectionStatus"]:
                return key
        return ""
    def _get_attr_val(self,inst,attr):
        split_attr = attr.split('.')
        for i in range(len(split_attr)):
            inst = self._get_val_map(inst, split_attr[i])
        return inst

    def _chk_excl(self, inst, excl_dict):
        """
        checks if instance is in excl_dict
        """
        for key,val in self.comp_param_map.items():
            excl_vals  = excl_dict.get(val)
            if (excl_vals):
                attr = self.comp_param_map[key]
                attr_val = self._get_attr_val(inst,key)
                if(attr_val in excl_vals):
                    return True
        return False