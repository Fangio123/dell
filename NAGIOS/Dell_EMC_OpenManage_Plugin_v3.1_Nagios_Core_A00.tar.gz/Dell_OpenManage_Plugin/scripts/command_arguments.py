import re

from dellemc_device_data_extractor import  write_log
import netaddr

class CommandArguments:
    command = ""
    host = ""
    inputport = None
    subnet = ""
    file = ""
    hostlist = []
    allservices = ""
    addservices = []
    removeservices = []
    service = ""
    exclude_instance = ""
    hostgroup = ""
    list_services = False
    filePath = ""
    cfg_location = ""
    protocol = ""
    service_tag = ""
    device_type = ""
    logLoc = ""
    nagios_type = 0
    error_massge = ""
    success_message = ""
    force_discover = False
    __instance = None


def copy_arguments(results,cfg_location):
    command_arguments = CommandArguments()
    command_arguments.host= results.host
    if(results.httpPort):
        command_arguments.inputPort = results.httpPort
    if(results.snmpPort):
        command_arguments.inputPort = results.snmpPort
    command_arguments.hostgroup=results.hostgroup
    command_arguments.subnet = results.subnet
    command_arguments.file = results.file
    if (command_arguments.file):
        command_arguments.hostlist = file_hosts(command_arguments,command_arguments.file)
    if(command_arguments.subnet):
        command_arguments.hostlist = subnet_hosts(command_arguments,command_arguments.subnet)
    if results.addservices:
        command_arguments.addservices = get_services(results.addservices)
    if results.removeservices:
        command_arguments.removeservices = get_services(results.removeservices)


    # command_arguments.addservices = results.addservices
    # command_arguments.removeservices = results.removeservices
    command_arguments.exclude_instance = results.exclude_instance
    command_arguments.service = results.service
    command_arguments.list_services = results.list_services
    command_arguments.cfg_location = cfg_location
    command_arguments.logLoc = results.logLoc
    command_arguments.force_discover = True if results.force else False
    command_arguments.allservices = True if results.all else False
    return command_arguments


def subnet_hosts(command_arguments,subnet):
    try:
        command_arguments.hostlist.extend([str(ip) for ip in netaddr.IPNetwork(subnet)])
    except netaddr.core.AddrFormatError:
        print("Error:Invalid subnet passed.Please pass correct value")
        write_log("Invalid subnet passed.Please pass correct value","error")
    return command_arguments.hostlist

def file_hosts(command_arguments,file):
    try:
        with open(file,"r") as fh :
            for line  in fh:
                if(line.rstrip().find("/")!=-1):
                    subnet_hosts(command_arguments,line.rstrip())
                else:
                    command_arguments.hostlist.append(line.rstrip())

    except IOError:
        print("Error:The input file is invalid,Please pass correct file path")
        write_log("The input file is invalid,Please pass correct file path","error")
    return command_arguments.hostlist

def get_services(services_string):
    services = []
    #Added split function if comma seperated componentname is in quotes
    split_list = re.split(r",(?=(?:[^'\"]*['\"][^'\"]*['\"])*[^'\"]*$)", services_string)
    for serv in split_list:
        services.append(serv.strip("'").strip('"'))
    return services
